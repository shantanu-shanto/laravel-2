@extends('partials.app')

@section('content')
    <div class="container py-5">
        <h1 class="text-center mb-4">Women's Clothing</h1>
        <!-- Add your women's clothing products here -->
    </div>
@endsection
