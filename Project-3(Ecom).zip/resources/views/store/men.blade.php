@extends('partials.app')

@section('content')
    <div class="container py-5">
        <h1 class="text-center mb-4">Men's Clothing</h1>
        <!-- Add your men's clothing products here -->
    </div>
@endsection
