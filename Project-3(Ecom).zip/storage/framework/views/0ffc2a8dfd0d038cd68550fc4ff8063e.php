


<?php $__env->startSection('content'); ?>

    <!-- Men Section -->
    <section id="men-products" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Men's Collection</h2>
            <div class="row">
                <?php for($i = 1; $i <= 6; $i++): ?>
                <div class="col-sm-6 col-md-4 col-lg-4 mb-4">
                    <div class="card custom-card" data-aos="fade-up">
                        <img src="<?php echo e(asset('images/men'.$i.'.jpg')); ?>" class="card-img-top" alt="Men Product <?php echo e($i); ?>">
                        <div class="card-body text-center">
                            <h5 class="card-title">Men's Product <?php echo e($i); ?></h5>
                            <a href="<?php echo e(url('/shop/men'.$i)); ?>" class="btn btn-primary">Buy Now</a>
                        </div>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    <!-- Women Section -->
    <section id="women-products" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Women's Collection</h2>
            <div class="row">
                <?php for($i = 1; $i <= 6; $i++): ?>
                <div class="col-sm-6 col-md-4 col-lg-4 mb-4">
                    <div class="card custom-card" data-aos="fade-up" data-aos-delay="<?php echo e($i * 100); ?>">
                        <img src="<?php echo e(asset('images/women'.$i.'.jpg')); ?>" class="card-img-top" alt="Women Product <?php echo e($i); ?>">
                        <div class="card-body text-center">
                            <h5 class="card-title">Women's Product <?php echo e($i); ?></h5>
                            <a href="<?php echo e(url('/shop/women'.$i)); ?>" class="btn btn-primary">Buy Now</a>
                        </div>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    <!-- Kids Section -->
    <section id="kids-products" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Kids' Collection</h2>
            <div class="row">
                <?php for($i = 1; $i <= 3; $i++): ?>
                <div class="col-sm-6 col-md-4 col-lg-4 mb-4">
                    <div class="card custom-card" data-aos="fade-up" data-aos-delay="<?php echo e($i * 100); ?>">
                        <img src="<?php echo e(asset('images/kid'.$i.'.jpg')); ?>" class="card-img-top" alt="Kids Product <?php echo e($i); ?>">
                        <div class="card-body text-center">
                            <h5 class="card-title">Kids' Product <?php echo e($i); ?></h5>
                            <a href="<?php echo e(url('/shop/kids'.$i)); ?>" class="btn btn-primary">Buy Now</a>
                        </div>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shant\Desktop\Project-3(Ecom)\resources\views/store/shop.blade.php ENDPATH**/ ?>