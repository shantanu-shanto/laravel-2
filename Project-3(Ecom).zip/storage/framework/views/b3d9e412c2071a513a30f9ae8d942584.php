<nav class="navbar navbar-expand-lg custom-navbar" data-aos="fade-down">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/clothlogo.jpg')); ?>" alt="Fashion Store Logo" style="height: 50px;">
            Fashion Store
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('shop') ? 'active' : ''); ?>" href="<?php echo e(url('/shop')); ?>">Store</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('about') ? 'active' : ''); ?>" href="<?php echo e(url('/about')); ?>">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('contact') ? 'active' : ''); ?>" href="<?php echo e(url('/contact')); ?>">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-primary text-white <?php echo e(Request::is('shop') ? 'active' : ''); ?>" href="<?php echo e(url('/shop')); ?>">Shop Now</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<?php /**PATH C:\Users\shant\Desktop\Project-3(Ecom)\resources\views\partials\navbar.blade.php ENDPATH**/ ?>