

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <h1 class="text-center mb-4">Men's Clothing</h1>
        <!-- Add your men's clothing products here -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shant\Desktop\Project-3(Ecom)\resources\views\store\men.blade.php ENDPATH**/ ?>